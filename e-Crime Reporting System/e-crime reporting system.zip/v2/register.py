
import sys

import mysql.connector

from ui.reg import Ui_regWindow
from PySide2.QtWidgets import (QMainWindow, QApplication)
import home as hm
from PySide2.QtWidgets import QMessageBox

mainSelf = None

def showRegisterWindow(self):
        regWindow = Register_Window()
        regWindow.show()

def checkPassword():
    rData = False
    passwd = mainSelf.txt_pwd.text()
    cPass = mainSelf.txt_cnfpwd.text()
    if (passwd == cPass):
        rData = True
    return rData

def checkUsername():
    rData = False
    cUsrName = mainSelf.txt_usrname.text()
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT * FROM acc WHERE username = '" + cUsrName + "'")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = True

    return rData

def setUserData(name, email, address):
    mainSelf.input_fname.setText(name)
    mainSelf.input_add.setText(address)
    mainSelf.input_mail.setText(email)

class Register_Window(QMainWindow, Ui_regWindow):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

       #self.txt_mno.setText("8805286288")
       #self.txt_adhar.setText("207552526365")


        self.btn_loginhere.mousePressEvent = self.showLoginWindow
        self.btn_validate.mousePressEvent = self.getAdhaarData
        self.btn_signup.mousePressEvent = self.registerUser

    def showLoginWindow(self, e):
        hm.showLoginWindow(self)
        self.close()

    def getAdhaarData(self, e):
        adhar = self.txt_adhar.text()
        mob = self.txt_mno.text()
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        dbCursor = mydb.cursor()
        dbCursor.execute("SELECT * FROM adhaar WHERE UID = " + adhar + " AND Mobile =" + mob + " LIMIT 1")
        dataResult = dbCursor.fetchone()

        if dataResult:
            getName = dataResult[0]
            getEmail = dataResult[3]
            getAddress = dataResult[4]
            setUserData(getName, getEmail, getAddress)
        else:
            print("NO DATA!")

    def registerUser(self, e):
        if checkUsername():
            print("INVALID Username")
            return
        if not checkPassword():
            print("INVALID")
            return

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        username = mainSelf.txt_usrname.text()
        pwd = mainSelf.txt_pwd.text()
        name = mainSelf.input_fname.text()
        adhaar = mainSelf.txt_adhar.text()
        mobile = mainSelf.txt_mno.text()
        email = mainSelf.input_mail.text()
        add = mainSelf.input_add.text()
        sql = "INSERT INTO acc (`username`, `pwd`, `name`, `adhaar`, `mobile`, `email`, `add`, `dtype`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (username, pwd, name, adhaar, mobile, email, add, "user")
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)

        mydb.commit()
        msg = QMessageBox()
        msg.setWindowTitle("Registration Form")
        msg.setText("Registration Successfull")
        x = msg.exec_()

        #ADD POPUP

        hm.showLoginWindow("TEST")
        mainSelf.close()

if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = Register_Window()
    regWindow.show()
    sys.exit(app.exec_())