
from ui.ui_viewreport import Ui_viewreport
from PySide2.QtWidgets import (QMainWindow, QApplication)
import mysql.connector, sys

caseid = ""
uName = ""
mainSelf = None

def showviewreport(username, cid):
    global uName, caseid
    caseid = cid
    uName = username
    pendingcaseWindow = viewreport_Window()
    pendingcaseWindow.show()

def getCaseDetials():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM caselist WHERE cid = '" + caseid + "' LIMIT 1")

    result = mycursor.fetchone()

    ts = result[0]
    dType = result[1]
    loca = result[2]
    status = result[5]
    desc = result[3]
    mainSelf.inp_caase.setText(caseid)
    mainSelf.inp_datetime.setText(ts)
    mainSelf.inp_type.setText(dType)
    mainSelf.inp_location.setText(loca)
    mainSelf.inp_status.setText(status)
    mainSelf.inp_desc.setText(desc)

def getUserDetails():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM acc WHERE username = '" + uName + "' LIMIT 1")

    result = mycursor.fetchone()

    fName = result[2]
    add = result[6]
    mob = result[4]
    email = result[5]
    adhaar = result[3]
    mainSelf.inp_fname.setText(fName)
    mainSelf.inp_adhaar.setText(adhaar)
    mainSelf.inp_add.setText(add)
    mainSelf.inp_phoneno.setText(mob)
    mainSelf.inp_desc_3.setText(email)



class viewreport_Window(QMainWindow, Ui_viewreport):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        getCaseDetials()
        getUserDetails()

        self.btn_ok.mousePressEvent = self.setCaseStatus
        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

    def setCaseStatus(self, e):
        status = self.comboBox_aprpve.currentText()

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        sql = "UPDATE caselist SET cstatus = '"+status+"' WHERE cid = '"+caseid+"'"
        mycursor.execute(sql)
        mydb.commit()
        mydb.close()

        self.close()



if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = viewreport_Window()
    regWindow.show()
    sys.exit(app.exec_())