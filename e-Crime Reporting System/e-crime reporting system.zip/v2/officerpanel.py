from PySide2.QtCore import QTimer
import datetime
from ui.ui_officerpanel import Ui_officerPanel
from PySide2.QtWidgets import (QMainWindow, QApplication)
import pendingcases as pc
import allcasesofficer as aco
import home as hm

uName = ""
mainSelf = None

def updateTime():
    x = datetime.datetime.now()
    dt = x.strftime("%H:%M")
    mainSelf.lbl_time.setText(dt)

main_timer = QTimer()
main_timer.timeout.connect(updateTime)

def showofficerPanelWindow(username):
    global uName
    uName = username
    officerPWindow = officerPanel_Window()
    officerPWindow.show()

class officerPanel_Window(QMainWindow, Ui_officerPanel):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        updateTime()
        main_timer.start(60000)

        self.btn_pending.mousePressEvent = self.pendingCases
        self.frame_3.mousePressEvent = self.pendingCases
        self.btn_allcases.mousePressEvent = self.allCases
        self.frame_4.mousePressEvent = self.allCases
        self.btn_back.mousePressEvent = self.logoutUser

    def logoutUser(self, e):
        hm.showLoginWindow("")
        self.close()

    def pendingCases(self, e):
        pc.showPendingCasesWindow(uName)

    def allCases(self, e):
        aco.showallcaseoffWindow(uName)