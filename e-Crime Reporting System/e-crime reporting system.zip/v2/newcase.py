import time

from ui.ui_newcase import Ui_Newcase
from PySide2.QtWidgets import (QMainWindow, QApplication)
from PySide2.QtCore import QTimer
import sys, datetime
import mysql.connector

uName = ""
mainSelf = None

def showNewCaseWindow(username):
    global uName
    uName = username
    newcaseWindow = NewCase_Window()
    newcaseWindow.show()

def getCaseId():
    rData = "CID000"

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    mycursor = mydb.cursor()

    # Execute the query
    query = "SELECT count(*) FROM caselist;"
    mycursor.execute(query)

    myresult = mycursor.fetchall()

    cCount = int(myresult[-1][-1]) + 1
    rData += str(cCount)
    mydb.close()

    return rData

def updateTime():
    x = datetime.datetime.now()
    dt = x.strftime("%A %d %B %Y %H:%M")
    mainSelf.dateTimeEdit.setText(dt)

main_timer = QTimer()
main_timer.timeout.connect(updateTime)

class NewCase_Window(QMainWindow, Ui_Newcase):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        updateTime()
        main_timer.start(60000)

        self.btn_submit.mousePressEvent = self.onSubmitButton
        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

    def onSubmitButton(self, e):
        ts = int(time.time())
        cType = self.tet_type.toPlainText()
        location = self.txt_loc.toPlainText()
        cDesp = self.txt_desc.toPlainText()

        if cType == "" or location == "" or cDesp == "":
            print("Input field missing!")
            return
        #btn_submit
        if not self.checkBox.isChecked():
            print("Please agree to the terms!")
            return

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        sql = "INSERT INTO caselist (`ts`, `ctype`, `loc`, `descr`, `uname`, `cstatus`, `cid`) VALUES (%s,%s,%s,%s,%s,%s,%s)"
        val = (ts, cType, location, cDesp, uName, "Pending", getCaseId())
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)

        mydb.commit()
        mydb.close()
        self.close()




