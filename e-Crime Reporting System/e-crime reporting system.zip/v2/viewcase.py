
from ui.ui_viewcase import Ui_viewcase
from PySide2.QtWidgets import (QMainWindow, QApplication)
import mysql.connector
uName = ""
caseid = ""
mainSelf = None

def showviewcaseCasesWindow(username, cid):
    global uName, caseid
    caseid = cid
    uName = username
    pendingcaseWindow = viewcase_Window()
    pendingcaseWindow.show()

class viewcase_Window(QMainWindow, Ui_viewcase):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM caselist WHERE cid = '" + caseid + "' LIMIT 1")

        result = mycursor.fetchone()
        print(result[0])

        ts = result[0]
        dType = result[1]
        loca = result[2]
        status = result[5]
        desc = result[3]
        self.inp_caase.setText(caseid)
        self.inp_datetime.setText(ts)
        self.inp_type.setText(dType)
        self.inp_location.setText(loca)
        self.inp_status.setText(status)
        self.inp_desc.setText(desc)

        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

