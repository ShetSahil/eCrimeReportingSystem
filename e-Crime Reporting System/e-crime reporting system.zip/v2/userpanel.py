from PySide2.QtCore import QTimer

from ui.ui_userpanel import Ui_userPanel
from PySide2.QtWidgets import (QMainWindow, QApplication)
import newcase as nc
import allcases as ac
import changepass as cp
import home as hm
import sys
import sys, datetime

uName = ""
mainSelf = None

def updateTime():
    x = datetime.datetime.now()
    dt = x.strftime("%H:%M")
    mainSelf.lbl_time.setText(dt)

main_timer = QTimer()
main_timer.timeout.connect(updateTime)

def showUserPanelWindow(username):
    global uName
    uName = username
    userPWindow = UserPanel_Window()
    userPWindow.show()

class UserPanel_Window(QMainWindow, Ui_userPanel):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        # self.move(parent.rect().center() - self.rect().center())

        updateTime()
        main_timer.start(60000)

        self.btn_newcase.mousePressEvent = self.newCase
        self.frame_2.mousePressEvent = self.newCase
        self.btn_casestatus.mousePressEvent = self.caseStatus
        self.frame_3.mousePressEvent = self.caseStatus
        self.btn_cngpwd.mousePressEvent = self.changePassword
        self.frame_4.mousePressEvent = self.changePassword
        self.btn_back.mousePressEvent = self.logoutUser

    def logoutUser(self, e):
        hm.showLoginWindow("")
        self.close()

    def newCase(self, e):
        nc.showNewCaseWindow(uName)

    def caseStatus(self, e):
        ac.showAllCasesWindow(uName)

    def changePassword(self, e):
        cp.showChangePass(uName)

if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = UserPanel_Window()
    regWindow.show()
    sys.exit(app.exec_())
