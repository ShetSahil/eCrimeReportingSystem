from PySide2 import QtWidgets

from ui.ui_userlist import Ui_Userlist
from PySide2.QtWidgets import (QMainWindow, QApplication, QTableWidgetItem, QTableView)
import mysql.connector
uName = ""
mainSelf = None

def showUserListWindow(username):
    global uName
    uName = username
    userlistWindow = userlist_Window()
    userlistWindow.show()

class userlist_Window(QMainWindow, Ui_Userlist):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM acc")

        result = mycursor.fetchall()

        self.allusers.setRowCount(0)

        for row_number, row_data in enumerate(result):
            usrName = row_data[0]
            fName = row_data[2]
            email = row_data[5]
            mob = row_data[4]

            self.allusers.insertRow(row_number)

            self.allusers.setItem(row_number, 0, QTableWidgetItem(str(usrName)))
            self.allusers.setItem(row_number, 1, QTableWidgetItem(str(fName)))
            self.allusers.setItem(row_number, 2, QTableWidgetItem(str(email)))
            self.allusers.setItem(row_number, 3, QTableWidgetItem(str(mob)))

        self.allusers.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.allusers.setSelectionBehavior(QTableView.SelectRows)

        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()


