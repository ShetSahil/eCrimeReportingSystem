# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'userpanel.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

class Ui_userPanel(object):
    def setupUi(self, user):
        if not user.objectName():
            user.setObjectName(u"user")
        user.resize(1196, 700)
        self.frame = QFrame(user)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1201, 80))
        self.frame.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(560, 20, 141, 41))
        font = QFont()
        font.setPointSize(26)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.btn_back = QPushButton(self.frame)
        self.btn_back.setObjectName(u"btn_back")
        self.btn_back.setGeometry(QRect(30, 30, 93, 28))
        self.lbl_time = QLabel(self.frame)
        self.lbl_time.setObjectName(u"lbl_time")
        self.lbl_time.setGeometry(QRect(1050, 20, 111, 41))
        font1 = QFont()
        font1.setPointSize(15)
        font1.setBold(True)
        font1.setWeight(75)
        self.lbl_time.setFont(font1)
        self.lbl_time.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.frame_2 = QFrame(user)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(100, 240, 241, 251))
        self.frame_2.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"border-radius: 30px;")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.btn_newcase = QPushButton(self.frame_2)
        self.btn_newcase.setObjectName(u"btn_newcase")
        self.btn_newcase.setGeometry(QRect(60, 190, 111, 28))
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75)
        self.btn_newcase.setFont(font2)
        self.btn_newcase.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_3 = QLabel(self.frame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(65, 10, 131, 181))
        self.label_3.setPixmap(QPixmap(u"img/newcase.png"))
        self.label_3.setStyleSheet(u"image: url(:/login/icons8-new-file-100.png);")
        self.label_3.raise_()
        self.btn_newcase.raise_()
        self.frame_3 = QFrame(user)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(470, 240, 241, 251))
        self.frame_3.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"border-radius: 30px;")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.btn_casestatus = QPushButton(self.frame_3)
        self.btn_casestatus.setObjectName(u"btn_casestatus")
        self.btn_casestatus.setGeometry(QRect(50, 190, 131, 28))
        self.btn_casestatus.setFont(font2)
        self.btn_casestatus.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_4 = QLabel(self.frame_3)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(65, 10, 131, 181))
        self.label_4.setPixmap(QPixmap(u"img/list.png"))
        self.label_4.setStyleSheet(u"image: url(:/login/icons8-list-100.png);")
        self.label_4.raise_()
        self.btn_casestatus.raise_()
        self.frame_4 = QFrame(user)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setGeometry(QRect(840, 240, 241, 251))
        self.frame_4.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"border-radius: 30px;")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.btn_cngpwd = QPushButton(self.frame_4)
        self.btn_cngpwd.setObjectName(u"btn_cngpwd")
        self.btn_cngpwd.setGeometry(QRect(30, 190, 181, 28))
        self.btn_cngpwd.setFont(font2)
        self.btn_cngpwd.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_5 = QLabel(self.frame_4)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(65, 0, 131, 181))
        self.label_5.setPixmap(QPixmap(u"img/password.png"))
        self.label_5.setStyleSheet(u"image: url(:/login/icons8-password-100.png);")
        self.label_5.raise_()
        self.btn_cngpwd.raise_()

        self.retranslateUi(user)

        QMetaObject.connectSlotsByName(user)
    # setupUi

    def retranslateUi(self, user):
        user.setWindowTitle(QCoreApplication.translate("user", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("user", u"USER", None))
        self.btn_back.setText(QCoreApplication.translate("user", u"Logout", None))
        self.lbl_time.setText(QCoreApplication.translate("user", u"Time", None))
        self.btn_newcase.setText(QCoreApplication.translate("user", u"New Case", None))
        self.label_3.setText("")
        self.btn_casestatus.setText(QCoreApplication.translate("user", u"Case Status", None))
        self.label_4.setText("")
        self.btn_cngpwd.setText(QCoreApplication.translate("user", u"Change password", None))
        self.label_5.setText("")
    # retranslateUi

