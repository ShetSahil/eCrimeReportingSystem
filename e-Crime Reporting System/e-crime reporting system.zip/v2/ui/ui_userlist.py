# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_userlist.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Userlist(object):
    def setupUi(self, Newcase):
        if not Newcase.objectName():
            Newcase.setObjectName(u"Newcase")
        Newcase.resize(1200, 700)
        font = QFont()
        font.setPointSize(10)
        Newcase.setFont(font)
        self.frame = QFrame(Newcase)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1201, 80))
        self.frame.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(560, 20, 261, 41))
        font1 = QFont()
        font1.setPointSize(26)
        font1.setBold(True)
        font1.setWeight(75)
        self.label.setFont(font1)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.btn_back = QPushButton(self.frame)
        self.btn_back.setObjectName(u"btn_back")
        self.btn_back.setGeometry(QRect(30, 30, 93, 28))
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75)
        self.allusers = QTableWidget(Newcase)
        if (self.allusers.columnCount() < 4):
            self.allusers.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.allusers.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.allusers.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.allusers.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.allusers.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.allusers.setObjectName(u"allusers")
        self.allusers.setGeometry(QRect(160, 150, 871, 461))

        self.allusers.setColumnWidth(0, 165)
        self.allusers.setColumnWidth(1, 280)
        self.allusers.setColumnWidth(2, 240)
        self.allusers.setColumnWidth(3, 170)
        font3 = QFont()
        font3.setPointSize(10)
        font3.setBold(True)
        font3.setWeight(75)
        self.allusers.setFont(font3)

        self.retranslateUi(Newcase)

        QMetaObject.connectSlotsByName(Newcase)
    # setupUi

    def retranslateUi(self, Newcase):
        Newcase.setWindowTitle(QCoreApplication.translate("Newcase", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("Newcase", u"Users", None))
        self.btn_back.setText(QCoreApplication.translate("Newcase", u"Back", None))
        ___qtablewidgetitem = self.allusers.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Newcase", u"Username", None));
        ___qtablewidgetitem1 = self.allusers.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Newcase", u"Full name ", None));
        ___qtablewidgetitem2 = self.allusers.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Newcase", u"Email", None));
        ___qtablewidgetitem3 = self.allusers.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Newcase", u"Phone", None));
    # retranslateUi

