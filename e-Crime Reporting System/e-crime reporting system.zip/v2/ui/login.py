# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

class Ui_Login(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(1194, 700)
        Dialog.setStyleSheet(u"")
        self.label = QLabel(Dialog)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(-330, -410, 1261, 1531))
        self.label.setPixmap(QPixmap(u"img/design  1.png"))
        self.label_2 = QLabel(Dialog)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(-50, -80, 901, 951))
        self.label_2.setPixmap(QPixmap(u"img/logimg.png"))
        self.label_3 = QLabel(Dialog)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(10, -10, 301, 131))
        #self.label_3.setPixmap(QPixmap(u"img/lbl_welcome.png"))
        self.label_4 = QLabel(Dialog)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(20, 40, 301, 131))
        #self.label_4.setPixmap(QPixmap(u"img/lbl_welcome2.png"))
        self.label_5 = QLabel(Dialog)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(805, 120, 121, 51))
        font = QFont()
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_7 = QLabel(Dialog)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(680, 310, 91, 16))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_7.setFont(font1)
        self.label_8 = QLabel(Dialog)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(680, 200, 101, 16))
        self.label_8.setFont(font1)
        self.txt_usrname = QLineEdit(Dialog)
        self.txt_usrname.setObjectName(u"txt_usrname")
        self.txt_usrname.setGeometry(QRect(680, 230, 371, 51))
        font2 = QFont()
        font2.setPointSize(14)
        font2.setBold(True)
        font2.setWeight(75)
        self.txt_usrname.setFont(font2)
        self.txt_usrname.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_pwd = QLineEdit(Dialog)
        self.txt_pwd.setObjectName(u"txt_pwd")
        self.txt_pwd.setGeometry(QRect(680, 340, 371, 51))
        self.txt_pwd.setFont(font2)
        self.txt_pwd.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_pwd.setEchoMode(QLineEdit.Password)
        self.pushButton = QPushButton(Dialog)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(810, 430, 131, 41))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setWeight(75)
        self.pushButton.setFont(font3)
        self.pushButton.setStyleSheet(u"")
        self.btn_signup = QPushButton(Dialog)
        self.btn_signup.setObjectName(u"btn_signup")
        self.btn_signup.setGeometry(QRect(720, 500, 301, 28))
        font4 = QFont()
        font4.setBold(True)
        font4.setWeight(75)
        self.btn_signup.setFont(font4)
     #   self.btn_signup_2 = QPushButton(Dialog)
    #    self.btn_signup_2.setObjectName(u"btn_signup_2")
       # self.btn_signup_2.setGeometry(QRect(920, 305, 131, 28))
       # self.btn_signup_2.setFont(font4)
        self.r_btn_user = QRadioButton(Dialog)
        self.r_btn_user.setObjectName(u"r_btn_user")
        self.r_btn_user.setGeometry(QRect(730, 400, 71, 20))
        font5 = QFont()
        font5.setPointSize(9)
        font5.setBold(True)
        font5.setWeight(75)
        self.r_btn_user.setFont(font5)
        self.r_btn_admin = QRadioButton(Dialog)
        self.r_btn_admin.setObjectName(u"r_btn_admin")
        self.r_btn_admin.setGeometry(QRect(830, 400, 81, 20))
        self.r_btn_admin.setFont(font5)
        self.r_btn_authority = QRadioButton(Dialog)
        self.r_btn_authority.setObjectName(u"r_btn_authority")
        self.r_btn_authority.setGeometry(QRect(920, 400, 95, 20))
        self.r_btn_authority.setFont(font5)
        self.label.raise_()
        self.label_3.raise_()
        self.label_4.raise_()
        self.label_5.raise_()
        self.label_7.raise_()
        self.label_8.raise_()
        self.pushButton.raise_()
    #    self.btn_signup_2.raise_()
        self.label_2.raise_()
        self.r_btn_admin.raise_()
        self.r_btn_authority.raise_()
        self.txt_usrname.raise_()
        self.txt_pwd.raise_()
        self.r_btn_user.raise_()
        self.btn_signup.raise_()

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label.setText("")
        self.label_2.setText("")
        self.label_3.setText("")
        self.label_4.setText("")
        self.label_5.setText(QCoreApplication.translate("Dialog", u"Login", None))
        self.label_7.setText(QCoreApplication.translate("Dialog", u"Password", None))
        self.label_8.setText(QCoreApplication.translate("Dialog", u"Username", None))
        self.pushButton.setText(QCoreApplication.translate("Dialog", u"LOGIN", None))
        self.btn_signup.setText(QCoreApplication.translate("Dialog", u"Doesn\u2019t have an account yet ? Sign Up", None))
     #   self.btn_signup_2.setText(QCoreApplication.translate("Dialog", u"Forgot password ?", None))
        self.r_btn_user.setText(QCoreApplication.translate("Dialog", u"User", None))
        self.r_btn_admin.setText(QCoreApplication.translate("Dialog", u"Admin", None))
        self.r_btn_authority.setText(QCoreApplication.translate("Dialog", u"Authority", None))
    # retranslateUi

