# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'newcase.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Newcase(object):
    def setupUi(self, Newcase):
        if not Newcase.objectName():
            Newcase.setObjectName(u"Newcase")
        Newcase.resize(1200, 700)
        font = QFont()
        font.setPointSize(10)
        Newcase.setFont(font)
        self.frame = QFrame(Newcase)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1201, 80))
        self.frame.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(500, 20, 261, 41))
        font1 = QFont()
        font1.setPointSize(26)
        font1.setBold(True)
        font1.setWeight(75)
        self.label.setFont(font1)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.btn_back = QPushButton(self.frame)
        self.btn_back.setObjectName(u"btn_back")
        self.btn_back.setGeometry(QRect(30, 30, 93, 28))
        self.label_2 = QLabel(Newcase)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(500, 90, 231, 61))
        font2 = QFont()
        font2.setPointSize(20)
        font2.setBold(True)
        font2.setWeight(75)
        self.label_2.setFont(font2)
        self.label_3 = QLabel(Newcase)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(250, 170, 151, 51))
        font3 = QFont()
        font3.setPointSize(15)
        font3.setBold(True)
        font3.setWeight(75)
        self.label_3.setFont(font3)
        self.dateTimeEdit = QLabel(Newcase)
        self.dateTimeEdit.setObjectName(u"dateTimeEdit")
        self.dateTimeEdit.setGeometry(QRect(430, 175, 400, 41))
        font4 = QFont()
        font4.setPointSize(10)
        font4.setBold(True)
        font4.setWeight(75)
        self.dateTimeEdit.setFont(font4)
        self.label_4 = QLabel(Newcase)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(250, 245, 151, 51))
        self.label_4.setFont(font3)
        self.label_5 = QLabel(Newcase)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(250, 315, 161, 51))
        self.label_5.setFont(font3)
        self.label_6 = QLabel(Newcase)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(250, 385, 161, 51))
        self.label_6.setFont(font3)
        self.tet_type = QTextEdit(Newcase)
        self.tet_type.setObjectName(u"tet_type")
        self.tet_type.setGeometry(QRect(430, 250, 501, 41))
        self.tet_type.setFont(font)
        self.txt_loc = QTextEdit(Newcase)
        self.txt_loc.setObjectName(u"txt_loc")
        self.txt_loc.setGeometry(QRect(430, 320, 501, 41))
        self.txt_loc.setFont(font)
        self.txt_desc = QTextEdit(Newcase)
        self.txt_desc.setObjectName(u"txt_desc")
        self.txt_desc.setGeometry(QRect(430, 390, 501, 191))
        self.txt_desc.setFont(font)
        self.btn_submit = QPushButton(Newcase)
        self.btn_submit.setObjectName(u"btn_submit")
        self.btn_submit.setGeometry(QRect(580, 640, 141, 41))
        font5 = QFont()
        font5.setPointSize(12)
        font5.setBold(True)
        font5.setWeight(75)
        self.btn_submit.setFont(font5)
        self.checkBox = QCheckBox(Newcase)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setGeometry(QRect(500, 600, 281, 31))
        font6 = QFont()
        font6.setBold(True)
        font6.setWeight(75)
        self.checkBox.setFont(font6)

        self.retranslateUi(Newcase)

        QMetaObject.connectSlotsByName(Newcase)
    # setupUi

    def retranslateUi(self, Newcase):
        Newcase.setWindowTitle(QCoreApplication.translate("Newcase", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("Newcase", u"New Case", None))
        self.btn_back.setText(QCoreApplication.translate("Newcase", u"Back", None))
        self.label_2.setText(QCoreApplication.translate("Newcase", u"Crime Details", None))
        self.label_3.setText(QCoreApplication.translate("Newcase", u"Date  Time :", None))
        self.label_4.setText(QCoreApplication.translate("Newcase", u"Type :", None))
        self.label_5.setText(QCoreApplication.translate("Newcase", u"Location :", None))
        self.label_6.setText(QCoreApplication.translate("Newcase", u"Description :", None))
        self.dateTimeEdit.setText(QCoreApplication.translate("Newcase", u"dateTime", None))

        self.btn_submit.setText(QCoreApplication.translate("Newcase", u"SUBMIT", None))
        self.checkBox.setText(QCoreApplication.translate("Newcase", u"  Accept all Terms & Condition.", None))
    # retranslateUi

