# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'reg.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

class Ui_regWindow(object):
    def setupUi(self, regWindow):
        if not regWindow.objectName():
            regWindow.setObjectName(u"regWindow")
        regWindow.resize(1200, 700)
        font = QFont()
        font.setBold(True)
        font.setWeight(75)
        regWindow.setFont(font)
        regWindow.setStyleSheet(u"background: #FFFFFF;\n"
"position: absolute;")
        self.lbl_register = QLabel(regWindow)
        self.lbl_register.setObjectName(u"lbl_register")
        self.lbl_register.setGeometry(QRect(130, 10, 311, 51))
        font1 = QFont()
        font1.setFamily(u"Arial Black")
        font1.setPointSize(20)
        self.lbl_register.setFont(font1)
        self.txt_mno = QLineEdit(regWindow)
        self.txt_mno.setObjectName(u"txt_mno")
        self.txt_mno.setGeometry(QRect(120, 80, 321, 31))
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setWeight(75)
        self.txt_mno.setFont(font2)
        self.txt_mno.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_mno.setEchoMode(QLineEdit.Normal)
        self.btn_validate = QPushButton(regWindow)
        self.btn_validate.setObjectName(u"btn_validate")
        self.btn_validate.setGeometry(QRect(220, 180, 111, 31))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setWeight(75)
        self.btn_validate.setFont(font3)
        self.btn_validate.setStyleSheet(u"")
        self.btn_loginhere = QPushButton(regWindow)
        self.btn_loginhere.setObjectName(u"btn_loginhere")
        self.btn_loginhere.setGeometry(QRect(120, 630, 301, 28))
        self.btn_loginhere.setFont(font)
        self.txt_adhar = QLineEdit(regWindow)
        self.txt_adhar.setObjectName(u"txt_adhar")
        self.txt_adhar.setGeometry(QRect(120, 130, 321, 31))
        self.txt_adhar.setFont(font2)
        self.txt_adhar.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_adhar.setEchoMode(QLineEdit.Normal)
        self.txt_pwd = QLineEdit(regWindow)
        self.txt_pwd.setObjectName(u"txt_pwd")
        self.txt_pwd.setGeometry(QRect(120, 470, 321, 31))
        self.txt_pwd.setFont(font2)
        self.txt_pwd.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_pwd.setEchoMode(QLineEdit.Password)
        self.label_9 = QLabel(regWindow)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(120, 450, 101, 16))
        self.label_9.setFont(font2)
        self.txt_usrname = QLineEdit(regWindow)
        self.txt_usrname.setObjectName(u"txt_usrname")
        self.txt_usrname.setGeometry(QRect(120, 410, 321, 31))
        self.txt_usrname.setFont(font2)
        self.txt_usrname.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_usrname.setEchoMode(QLineEdit.Normal)
        self.label_10 = QLabel(regWindow)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(120, 390, 91, 16))
        self.label_10.setFont(font2)
        self.label_11 = QLabel(regWindow)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(120, 510, 171, 16))
        self.label_11.setFont(font2)
        self.txt_cnfpwd = QLineEdit(regWindow)
        self.txt_cnfpwd.setObjectName(u"txt_cnfpwd")
        self.txt_cnfpwd.setGeometry(QRect(120, 530, 321, 31))
        self.txt_cnfpwd.setFont(font2)
        self.txt_cnfpwd.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.txt_cnfpwd.setEchoMode(QLineEdit.Password)
        self.label_12 = QLabel(regWindow)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(120, 270, 101, 16))
        self.label_12.setFont(font2)
        self.label_13 = QLabel(regWindow)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(120, 330, 171, 16))
        self.label_13.setFont(font2)
        self.label_14 = QLabel(regWindow)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(120, 210, 91, 16))
        self.label_14.setFont(font2)
        self.input_fname = QLabel(regWindow)
        self.input_fname.setObjectName(u"input_fname")
        self.input_fname.setGeometry(QRect(120, 230, 321, 31))
        self.input_fname.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.input_mail = QLabel(regWindow)
        self.input_mail.setObjectName(u"input_mail")
        self.input_mail.setGeometry(QRect(120, 290, 321, 31))
        self.input_mail.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.input_add = QLabel(regWindow)
        self.input_add.setObjectName(u"input_add")
        self.input_add.setGeometry(QRect(120, 350, 321, 31))
        self.input_add.setStyleSheet(u"background: #FFFFFF;\n"
"border: 3px solid #2CBA7E;\n"
"box-sizing: border-box;\n"
"border-radius: 5px;")
        self.btn_signup = QPushButton(regWindow)
        self.btn_signup.setObjectName(u"btn_signup")
        self.btn_signup.setGeometry(QRect(210, 570, 121, 41))
        self.btn_signup.setFont(font3)
        self.btn_signup.setStyleSheet(u"")
        self.label = QLabel(regWindow)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(590, -50, 631, 911))
        self.label.setPixmap(QPixmap(u"img/design  2.png"))
        self.label_2 = QLabel(regWindow)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(680, 50, 481, 541))
        self.label_2.setPixmap(QPixmap(u"img/regimg 1.png"))
        self.label_2.setStyleSheet(
"background: #2CBA7E;\n"
"position: absolute;\n"
"")
        self.label.raise_()
        self.lbl_register.raise_()
        self.txt_mno.raise_()
        self.btn_validate.raise_()
        self.btn_loginhere.raise_()
        self.txt_adhar.raise_()
        self.txt_pwd.raise_()
        self.label_9.raise_()
        self.txt_usrname.raise_()
        self.label_10.raise_()
        self.label_11.raise_()
        self.txt_cnfpwd.raise_()
        self.label_12.raise_()
        self.label_13.raise_()
        self.label_14.raise_()
        self.input_fname.raise_()
        self.input_mail.raise_()
        self.input_add.raise_()
        self.btn_signup.raise_()
        self.label_2.raise_()

        self.retranslateUi(regWindow)

        QMetaObject.connectSlotsByName(regWindow)
    # setupUi

    def retranslateUi(self, regWindow):
        regWindow.setWindowTitle(QCoreApplication.translate("regWindow", u"regWindow", None))
        self.lbl_register.setText(QCoreApplication.translate("regWindow", u"REGISTER HERE", None))
        self.txt_mno.setPlaceholderText(QCoreApplication.translate("regWindow", u"Mobile No", None))
        self.btn_validate.setText(QCoreApplication.translate("regWindow", u"Validate", None))
        self.btn_loginhere.setText(QCoreApplication.translate("regWindow", u"Already Have Account?Login here", None))
        self.txt_adhar.setPlaceholderText(QCoreApplication.translate("regWindow", u"Adhaar No.", None))
        self.label_9.setText(QCoreApplication.translate("regWindow", u"Password", None))
        self.label_10.setText(QCoreApplication.translate("regWindow", u"Username", None))
        self.label_11.setText(QCoreApplication.translate("regWindow", u"Confirm Password", None))
        self.label_12.setText(QCoreApplication.translate("regWindow", u"E-mail", None))
        self.label_13.setText(QCoreApplication.translate("regWindow", u"Address", None))
        self.label_14.setText(QCoreApplication.translate("regWindow", u"Full Name :", None))
        self.input_fname.setText(QCoreApplication.translate("regWindow", u"input", None))
        self.input_mail.setText(QCoreApplication.translate("regWindow", u"input", None))
        self.input_add.setText(QCoreApplication.translate("regWindow", u"input", None))
        self.btn_signup.setText(QCoreApplication.translate("regWindow", u"Sign Up", None))
        self.label.setText("")
        self.label_2.setText("")
    # retranslateUi

