# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'userofficer.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_officerPanel(object):
    def setupUi(self, officier):
        if not officier.objectName():
            officier.setObjectName(u"officier")
        officier.resize(1196, 700)
        self.frame = QFrame(officier)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1201, 80))
        self.frame.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(550, 20, 201, 41))
        font = QFont()
        font.setPointSize(26)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.btn_back = QPushButton(self.frame)
        self.btn_back.setObjectName(u"btn_back")
        self.btn_back.setGeometry(QRect(30, 30, 93, 28))
        self.lbl_time = QLabel(self.frame)
        self.lbl_time.setObjectName(u"lbl_time")
        self.lbl_time.setGeometry(QRect(1050, 20, 111, 41))
        font1 = QFont()
        font1.setPointSize(15)
        font1.setBold(True)
        font1.setWeight(75)
        self.lbl_time.setFont(font1)
        self.lbl_time.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.frame_3 = QFrame(officier)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(250, 240, 241, 251))
        self.frame_3.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"border-radius: 30px;")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.btn_pending = QPushButton(self.frame_3)
        self.btn_pending.setObjectName(u"btn_pending")
        self.btn_pending.setGeometry(QRect(40, 200, 161, 28))
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75)
        self.btn_pending.setFont(font2)
        self.btn_pending.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_3 = QLabel(self.frame_3)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(65, 30, 171, 171))
        self.label_3.setPixmap(QPixmap(u"img/pending.png"))
        self.label_3.setStyleSheet(u"image: url(:/officer/icons8-data-pending-100.png);")
        self.frame_4 = QFrame(officier)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setGeometry(QRect(710, 240, 241, 251))
        self.frame_4.setStyleSheet(u"background-color: rgb(44, 186, 126);\n"
"border-radius: 30px;")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.btn_allcases = QPushButton(self.frame_4)
        self.btn_allcases.setObjectName(u"btn_allcases")
        self.btn_allcases.setGeometry(QRect(30, 200, 181, 28))
        self.btn_allcases.setFont(font2)
        self.btn_allcases.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_4 = QLabel(self.frame_4)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(65, 30, 171, 171))
        self.label_4.setPixmap(QPixmap(u"img/list.png"))
        self.label_4.setStyleSheet(u"image: url(:/officer/icons8-list-100.png);")

        self.retranslateUi(officier)

        QMetaObject.connectSlotsByName(officier)
    # setupUi

    def retranslateUi(self, officier):
        officier.setWindowTitle(QCoreApplication.translate("officier", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("officier", u"OFFICER", None))
        self.btn_back.setText(QCoreApplication.translate("officier", u"Logout", None))
        self.lbl_time.setText(QCoreApplication.translate("officier", u"Time", None))
        self.btn_pending.setText(QCoreApplication.translate("officier", u"Pending Cases", None))
        self.label_3.setText("")
        self.btn_allcases.setText(QCoreApplication.translate("officier", u"All Cases", None))
        self.label_4.setText("")
    # retranslateUi

