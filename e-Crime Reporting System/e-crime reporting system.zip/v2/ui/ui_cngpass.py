# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'cngpass.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class ui_cngpass(object):
    def setupUi(self, ui_cngpass):
        if not ui_cngpass.objectName():
            ui_cngpass.setObjectName(u"ui_cngpass")
        ui_cngpass.resize(455, 330)
        self.centralwidget = QWidget(ui_cngpass)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 461, 51))
        self.frame.setStyleSheet(u"background-color:#2CBA7E;\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(120, 15, 241, 20))
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(90, 80, 121, 16))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_2.setFont(font1)
        self.label_3 = QLabel(self.centralwidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(90, 140, 131, 16))
        self.label_3.setFont(font1)
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(90, 200, 161, 16))
        self.label_4.setFont(font1)
        self.txt_oldpass = QLineEdit(self.centralwidget)
        self.txt_oldpass.setObjectName(u"txt_oldpass")
        self.txt_oldpass.setGeometry(QRect(90, 100, 281, 31))
        self.txt_oldpass.setStyleSheet(u"border: 3px solid #2CBA7E;")
        self.txt_oldpass.setEchoMode(QLineEdit.Password)
        self.txt_newpass = QLineEdit(self.centralwidget)
        self.txt_newpass.setObjectName(u"txt_newpass")
        self.txt_newpass.setGeometry(QRect(90, 160, 281, 31))
        self.txt_newpass.setStyleSheet(u"border: 3px solid #2CBA7E;\n"
"")
        self.txt_newpass.setEchoMode(QLineEdit.Password)
        self.txt_cnfpass = QLineEdit(self.centralwidget)
        self.txt_cnfpass.setObjectName(u"txt_cnfpass")
        self.txt_cnfpass.setGeometry(QRect(90, 220, 281, 31))
        self.txt_cnfpass.setStyleSheet(u"border: 3px solid #2CBA7E;")
        self.txt_cnfpass.setEchoMode(QLineEdit.Password)
        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(190, 280, 93, 28))
        font2 = QFont()
        font2.setBold(True)
        font2.setWeight(75)
        self.pushButton.setFont(font2)
        ui_cngpass.setCentralWidget(self.centralwidget)

        self.retranslateUi(ui_cngpass)

        QMetaObject.connectSlotsByName(ui_cngpass)
    # setupUi

    def retranslateUi(self, ui_cngpass):
        ui_cngpass.setWindowTitle(QCoreApplication.translate("ui_cngpass", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("ui_cngpass", u"CHANGE PASSWORD", None))
        self.label_2.setText(QCoreApplication.translate("ui_cngpass", u"Old Password ", None))
        self.label_3.setText(QCoreApplication.translate("ui_cngpass", u"New Password ", None))
        self.label_4.setText(QCoreApplication.translate("ui_cngpass", u"Confirm Password ", None))
        self.pushButton.setText(QCoreApplication.translate("ui_cngpass", u"OK", None))
    # retranslateUi

