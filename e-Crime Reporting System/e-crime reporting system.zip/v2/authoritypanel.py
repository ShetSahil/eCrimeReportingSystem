from PySide2.QtCore import QTimer
import datetime
from ui.ui_authority import Ui_authPanel
from PySide2.QtWidgets import (QMainWindow, QApplication)
import sys, mysql.connector
import allcasesofficer as aco
import userlist as ulist
import noactioncase as nac
import home as hm
uName = ""
tempSelf = None

def updateTime():
    x = datetime.datetime.now()
    dt = x.strftime("%H:%M")
    mainSelf.lbl_time.setText(dt)

main_timer = QTimer()
main_timer.timeout.connect(updateTime)

def showAuthWindow(username):
    global uName
    uName = username
    authPWindow = authPanel_Window()
    authPWindow.show()

class authPanel_Window(QMainWindow, Ui_authPanel):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        updateTime()
        main_timer.start(60000)

        self.btn_nonactioncase.mousePressEvent = self.noActionList
        self.frame_2.mousePressEvent = self.noActionList
        self.btn_Allcases.mousePressEvent = self.allCases
        self.frame_3.mousePressEvent = self.allCases
        self.btn_users.mousePressEvent = self.userList
        self.frame_4.mousePressEvent = self.userList
        self.btn_back.mousePressEvent = self.logoutUser

    def logoutUser(self, e):
        hm.showLoginWindow("")
        self.close()

    def noActionList(self, e):
        nac.showNonactionWindow(uName)

    def allCases(self, e):
        aco.showallcaseoffWindow(uName)

    def userList(self, e):
        ulist.showUserListWindow(uName)

if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = authPanel_Window()
    regWindow.show()
    sys.exit(app.exec_())
