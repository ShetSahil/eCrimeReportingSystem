from PySide2 import QtWidgets

from ui.ui_allcasesofficer import Ui_Allcasesofficer
from PySide2.QtWidgets import (QMainWindow, QApplication, QTableWidgetItem, QTableView)
import mysql.connector, sys
import viewreport as vr
uName = ""
mainSelf = None

def getFullName(userName):
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT name FROM acc WHERE username = '" + userName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

def getMobileNo(userName):
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT mobile FROM acc WHERE username = '" + userName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

def showallcaseoffWindow(username):
    global uName
    uName = username
    allcaseoffWindow = AllCasesofficer_Window()
    allcaseoffWindow.show()

def loadAllCases(v):
    mainSelf.Allcasestable.setRowCount(0);
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    mycursor = mydb.cursor()
    sql = "SELECT * FROM caselist"
    if (not v == "All"):
        sql += " WHERE cstatus = '"+v+"'"
    print(sql)
    mycursor.execute(sql)

    result = mycursor.fetchall()

    mainSelf.Allcasestable.setRowCount(0)

    for row_number, row_data in enumerate(result):
        cID = row_data[6]
        userName = row_data[4]
        fName = getFullName(userName)
        uMob = getMobileNo(userName)
        cStatus = row_data[5]

        mainSelf.Allcasestable.insertRow(row_number)

        mainSelf.Allcasestable.setItem(row_number, 0, QTableWidgetItem(str(cID)))
        mainSelf.Allcasestable.setItem(row_number, 1, QTableWidgetItem(str(fName)))
        mainSelf.Allcasestable.setItem(row_number, 2, QTableWidgetItem(str(userName)))
        mainSelf.Allcasestable.setItem(row_number, 3, QTableWidgetItem(str(uMob)))
        mainSelf.Allcasestable.setItem(row_number, 4, QTableWidgetItem(str(cStatus)))

class AllCasesofficer_Window(QMainWindow, Ui_Allcasesofficer):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        self.Allcasestable.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.Allcasestable.setSelectionBehavior(QTableView.SelectRows)

        loadAllCases("All")

        self.Allcasestable.doubleClicked.connect(self.onClickTable)
        self.comboBox.currentTextChanged.connect(self.onComboChange)
        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

    def onComboChange(self, v):
        loadAllCases(v)

    def onClickTable(self, mi):
        row = mi.row()
        caseid = self.Allcasestable.item(row, 0).text()
        userN = self.Allcasestable.item(row, 2).text()

        vr.showviewreport(userN, caseid)

if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = AllCasesofficer_Window()
    regWindow.show()
    sys.exit(app.exec_())

