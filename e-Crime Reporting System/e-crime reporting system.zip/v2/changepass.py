from ui.ui_cngpass import ui_cngpass
from PySide2.QtWidgets import (QMainWindow, QApplication)
import mysql.connector
uName = ""
mainSelf = None

def showChangePass(username):
    global uName
    uName = username
    cpWindow = changepass_window()
    cpWindow.show()

def checkOldPass(oldPass):
    rData = False
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT * FROM acc WHERE username = '" + uName + "' AND pwd = '" + oldPass + "'")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = True

    return rData

class changepass_window(QMainWindow, ui_cngpass):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        self.pushButton.mousePressEvent = self.changePass

    def changePass(self, e):
        oldPass = self.txt_oldpass.text()
        newPass = self.txt_newpass.text()
        cnfPass = self.txt_cnfpass.text()

        if not newPass == cnfPass:
            print("New pass did not match!")
            return

        if not checkOldPass(oldPass):
            print ("Old Password doesnt not match!")
            return

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        sql = "UPDATE acc SET pwd = '" + newPass + "' WHERE username = '" + uName + "'"
        mycursor.execute(sql)
        mydb.commit()
        mydb.close()
        print("Password Updated!")
        self.close()


