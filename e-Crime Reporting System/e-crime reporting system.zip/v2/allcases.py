from PySide2 import QtWidgets

from ui.ui_allcases import Ui_Allcases
from PySide2.QtWidgets import (QMainWindow, QApplication, QTableWidgetItem, QTableView)
import mysql.connector, sys
import viewcase as vc

uName = ""
mainSelf = None

def showAllCasesWindow(username):
    global uName
    uName = username
    allcasesWindow = AllCases_Window()
    allcasesWindow.show()

def getFullName():
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT name FROM acc WHERE username = '" + uName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

def getMobileNo():
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT mobile FROM acc WHERE username = '" + uName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

class AllCases_Window(QMainWindow, Ui_Allcases):
    def __init__(self, parent=None):
        global mainSelf, uName
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM caselist WHERE uname = '" + uName + "'")

        result = mycursor.fetchall()

        self.Allcasestable.setRowCount(0)

        for row_number, row_data in enumerate(result):
            cID = row_data[6]
            fName = getFullName()
            userName = row_data[4]
            uMob = getMobileNo()
            cStatus = row_data[5]

            self.Allcasestable.insertRow(row_number)

            self.Allcasestable.setItem(row_number, 0, QTableWidgetItem(str(cID)))
            self.Allcasestable.setItem(row_number, 1, QTableWidgetItem(str(fName)))
            self.Allcasestable.setItem(row_number, 2, QTableWidgetItem(str(userName)))
            self.Allcasestable.setItem(row_number, 3, QTableWidgetItem(str(uMob)))
            self.Allcasestable.setItem(row_number, 4, QTableWidgetItem(str(cStatus)))

        self.Allcasestable.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.Allcasestable.setSelectionBehavior(QTableView.SelectRows)

        self.Allcasestable.doubleClicked.connect(self.onClickTable)
        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

    def onClickTable(self, mi):
        row = mi.row()
        caseid = self.Allcasestable.item(row, 0).text()

        vc.showviewcaseCasesWindow(uName, caseid)


if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = AllCases_Window()
    regWindow.show()
    sys.exit(app.exec_())


