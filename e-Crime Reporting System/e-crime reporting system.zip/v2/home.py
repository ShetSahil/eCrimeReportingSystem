
from PySide2.QtWidgets import *
from ui.login import Ui_Login
import mysql.connector
import sys
from PySide2.QtWidgets import (QMainWindow, QApplication)
import register as rg
import userpanel as uPanel
import officerpanel as oPanel
import authoritypanel as aPanel
from PySide2.QtWidgets import QMessageBox

mainSelf = None

def showLoginWindow(arg):
    loginWindow = Login_Window()
    loginWindow.show()

def loginAuth(uName, uPass, uType):
    rData = False
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT * FROM acc WHERE username = '" + uName + "' AND pwd = '"+uPass+"' AND dtype = '"+uType+"'")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = True

    return rData

class Login_Window(QMainWindow, Ui_Login):
    def __init__(self, parent=None):
        global mainSelf
        mainSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())
        self.txt_usrname.setText("")
        self.txt_pwd.setText("")

        self.btn_signup.mousePressEvent = self.showRegisterWindow
        self.pushButton.mousePressEvent = self.loginUser

    def loginUser(self, e):
        userName = self.txt_usrname.text()
        userPass = self.txt_pwd.text()
        if userName == "" or userPass == "":
            print("USERNAME OR PASSWORD MISSING!")
            return

        if self.r_btn_user.isChecked():
            if not loginAuth(userName, userPass, "user"):
                msg = QMessageBox()
                msg.setWindowTitle("warning")
                msg.setText("login failed")
                msg.setIcon(QMessageBox.Warning)
                x = msg.exec_()
                return
            uPanel.showUserPanelWindow(userName)
            self.close()
        elif self.r_btn_admin.isChecked():
            if not loginAuth(userName, userPass, "admin"):
                msg = QMessageBox()
                msg.setWindowTitle("warning")
                msg.setText("login failed")
                msg.setIcon(QMessageBox.Warning)
                x = msg.exec_()
                return
            oPanel.showofficerPanelWindow(userName)
            self.close()
        elif self.r_btn_authority.isChecked():
            if not loginAuth(userName, userPass, "auth"):
                msg = QMessageBox()
                msg.setWindowTitle("warning")
                msg.setText("login failed")
                msg.setIcon(QMessageBox.Warning)
                x = msg.exec_()
                return
            aPanel.showAuthWindow(userName)
            self.close()
        else:
            print("Select Radio Button!")

    def showRegisterWindow(self, event):
        rg.showRegisterWindow(self)
        self.close()

if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = Login_Window()
    regWindow.show()
    sys.exit(app.exec_())

