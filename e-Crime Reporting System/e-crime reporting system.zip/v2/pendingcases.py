from PySide2 import QtWidgets

from ui.ui_pendingcases import Ui_pendingcases
from PySide2.QtWidgets import (QMainWindow, QApplication, QTableWidgetItem, QTableView)
import mysql.connector, sys
import viewreport as vr

uName = ""
mainSelf = None

def showPendingCasesWindow(username):
    global uName
    uName = username
    pendingcaseWindow = pendingcase_Window()
    pendingcaseWindow.show()

def getFullName(userName):
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT name FROM acc WHERE username = '" + userName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

def getMobileNo(userName):
    rData = ""
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="dbms2"
    )

    dbCursor = mydb.cursor()
    dbCursor.execute("SELECT mobile FROM acc WHERE username = '" + userName + "' LIMIT 1")
    dataResult = dbCursor.fetchone()

    if dataResult:
        rData = dataResult[0]
    else:
        print("NO DATA!")

    return rData

class pendingcase_Window(QMainWindow, Ui_pendingcases):
    def __init__(self, parent=None):
        global tempSelf
        tempSelf = self
        QMainWindow.__init__(self, parent)
        self.setupUi(self)
        #self.move(parent.rect().center() - self.rect().center())

        self.Allcasestable.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.Allcasestable.setSelectionBehavior(QTableView.SelectRows)

        self.Allcasestable.doubleClicked.connect(self.onClickTable)

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="dbms2"
        )

        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM caselist WHERE cstatus = 'Pending'")

        result = mycursor.fetchall()

        self.Allcasestable.setRowCount(0)

        for row_number, row_data in enumerate(result):
            cID = row_data[6]
            userName = row_data[4]
            fName = getFullName(userName)
            uMob = getMobileNo(userName)
            cStatus = row_data[5]

            self.Allcasestable.insertRow(row_number)

            self.Allcasestable.setItem(row_number, 0, QTableWidgetItem(str(cID)))
            self.Allcasestable.setItem(row_number, 1, QTableWidgetItem(str(fName)))
            self.Allcasestable.setItem(row_number, 2, QTableWidgetItem(str(userName)))
            self.Allcasestable.setItem(row_number, 3, QTableWidgetItem(str(uMob)))
            self.Allcasestable.setItem(row_number, 4, QTableWidgetItem(str(cStatus)))

        self.btn_back.mousePressEvent = self.backButton

    def backButton(self, e):
        self.close()

    def onClickTable(self, mi):
        row = mi.row()
        caseid = self.Allcasestable.item(row, 0).text()
        userN = self.Allcasestable.item(row, 2).text()

        vr.showviewreport(userN, caseid)


if (__name__ == '__main__'):
    app = QApplication(sys.argv)
    regWindow = pendingcase_Window()
    regWindow.show()
    sys.exit(app.exec_())
